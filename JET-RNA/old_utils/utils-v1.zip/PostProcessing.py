import numpy as np
import pandas as pd
from utils.PostProcessingUtils import *

"""
- unpad_matrix 
- edmunds_matching_algorithm
- get_pairings_from_matrix
- get_pk_indices
- pairings_to_dbn
- kth_diag_indices
- set_diagonals_to_zero
plot_dbn_graph
plot_dbn_figure
save_dbn_figure
"""


def post_processing(
    predictions: np.ndarray,
    true_lengths: pd.Series,
    return_dbn: bool = True,
    return_unpadded_matrices: bool = False,
    return_edmunds_matrices: bool = False,
    return_pairings: bool = False,
    return_pk_indices: bool = False,
):
    """
    Processes the predictions made by model into pairings in dot-bracket notation.

    Notes:To save the returned values, use
    'pd.DataFrame(pred_unpad).to_csv(filename, header=False, index=False)'

    Args:
        predictions (np.ndarray): List of predicted target matrices.
        true_lengths (pd.Series): List of true lengths.
        return_dbn (bool): If dot-bracket notation is to be returned.
        return_edmunds_matrix (bool): If target matrix is to be returned.
        return_pairings (bool):
        return_pk_indices (bool):

    Returns:
        processed_matrix: Target matrix
        dbn: Dot-bracket notation.
        pk_indices

    Raises:
    """

    returns = []
    unpadded_matrices_collection = []
    diagonal_matrices_collection = []
    edmunds_matrices_collection = []
    pairings_list_collection = []
    pk_indices_collection = []
    pairings_dbn_collection = []

    num_samples = predictions.shape[0]

    for idx in range(num_samples):
        dim = true_lengths.iloc[idx].item()

        # Unpad matrices
        unpadded_matrix = unpad_matrix(
            predictions[idx][:, :, 0],
            dim=dim,
        )
        unpadded_matrices_collection.append(unpadded_matrix)

        # Set main diagonals to 0
        diagonal_matrix = set_diagonals_to_zero(unpadded_matrix)
        diagonal_matrices_collection.append(diagonal_matrix)

        # Apply Edmund's matching algorithm
        edmunds_matrix = edmunds_matching_algorithm(diagonal_matrix, dim)
        edmunds_matrices_collection.append(edmunds_matrix)

        # Get pairings
        pairings_list = get_pairings_from_matrix(edmunds_matrix, dim)
        pairings_list_collection.append(pairings_list)

        # Convert pairings to dbn
        dbn = pairings_to_dbn(pairings_list, dim)
        pairings_dbn_collection.append(dbn)

    # Returns
    return_count = 0
    if return_unpadded_matrices:
        returns.append(unpadded_matrices_collection)
        return_count += 1
    if return_edmunds_matrices:
        returns.append(edmunds_matrices_collection)
        return_count += 1
    if return_pairings:
        returns.append(pairings_list)
        return_count += 1
    if return_pk_indices:
        for pairing in pairings_list_collection:
            pk_indices_collection.append(get_pk_indices(pairing))
        returns.append(pk_indices_collection)
        return_count += 1
    if return_dbn:
        returns.append(pairings_dbn_collection)
        return_count += 1

    return returns if return_count > 1 else returns[0]
