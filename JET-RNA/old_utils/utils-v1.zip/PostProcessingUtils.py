import numpy as np
import tensorflow as tf
import networkx as nx
import ViennaRNA
import forgi
import biotite
import biotite.structure
import matplotlib
import matplotlib.pyplot as plt

"""
Required packages:
  networkx
  biotite
  viennarna
  forgi "pip install --use-pep517 forgi"
"""


def unpad_matrix(matrix: np.ndarray, dim: int):
    """
    ADAPTED FROM:
    Saman Booy, M., Ilin, A. & Orponen, P. RNA secondary structure prediction with convolutional neural networks.
    BMC Bioinformatics 23, 58 (2022). https://doi.org/10.1186/s12859-021-04540-7
    --------------------------------------------------

    Turn a padded matrix into an unpadded one.
    Assumes matrix has center padding.

    Args:
        matrix (numpy.ndarray): Matrix to be unpadded.
        dim (int): Dimension of the original matrix.

    Returns:
        unpadded_matrix (numpy.ndarray): The unpadded matrix.

    Raises:
        ValueError: If dim is larger than the length of the padded matrix.
    """
    current_size = matrix.shape[0]
    if dim > current_size:
        raise ValueError(
            "Length of the final matrix is larger than the length of the padded matrix."
        )

    pad_len = current_size // 2 - dim // 2

    unpadded_matrix = matrix[pad_len : pad_len + dim, pad_len : pad_len + dim]

    return unpadded_matrix


def edmunds_matching_algorithm(matrix: np.ndarray, dim: int):
    """
    ADAPTED FROM:
    Saman Booy, M., Ilin, A. & Orponen, P. RNA secondary structure prediction with convolutional neural networks.
    BMC Bioinformatics 23, 58 (2022). https://doi.org/10.1186/s12859-021-04540-7
    --------------------------------------------------

    Args:
      matrix (numpy.ndarray): Probability matrix indicating pairing possibilities.
      dim (int): Dimension of the original matrix.

    Returns:
      edmunds_matrix (numpy.ndarray): Matrix representing pairings.
    """
    mask = np.eye(dim)
    big_a = np.zeros((2 * dim, 2 * dim))
    big_a[:dim, :dim] = matrix
    big_a[dim:, dim:] = matrix
    big_a[:dim, dim:] = matrix * mask
    big_a[dim:, :dim] = matrix * mask
    G = nx.from_numpy_array(big_a)
    pairings = nx.matching.max_weight_matching(G)
    edmunds_matrix = np.zeros_like(matrix)
    for i, j in pairings:
        if i > dim and j > dim:
            continue
        edmunds_matrix[i % dim, j % dim] = 1
        edmunds_matrix[j % dim, i % dim] = 1

    return edmunds_matrix


def get_pairings_from_matrix(matrix: np.ndarray, dim: int):
    """
    Get pairings from a matching matrix.

    Args:
      matrix (numpy.ndarray): Matrix of 1s and 0s indicating pairs (numpy.ndarray).
      dim (int): Dimensions of matching matrix (int).

    Returns:
      pairings_list (list): List of tuples indicating paired indices (list).
    """
    pairings_list = []
    u = np.triu_indices(dim, k=2)
    u_val = matrix[np.triu_indices(dim, k=2)]
    for idx in range(len(u_val)):
        if u_val[idx] == 1:
            pairings_list.append((u[0][idx], u[1][idx]))

    return pairings_list


def get_pk_order(pairings_list: list):
    """
    Gets the pseudoknot values from a list of paired indices.

    Args:
        pairings_list (list): List containing pairings.

    Returns:
        pk_orders (list): List containing indices of pairings (1 for pk, 0 for non-pk) in pairing list.
    """
    pairings_list = np.array(pairings_list)
    pk_orders = pseudoknots(pairings_list)[0]
    return pk_orders


def get_pk_indices(pairings_list: list, pk_order: list):
    """
    Get the indices of pseudoknot pairs.

    Args:
      pairings_list (list): List of pairings.
      pk_order (list): List of pseudoknot ordering for each pair.

    Returns:
      pk_indices (list): Indices of pseudoknot pairs
    """
    pk_indices = [pairings_list[idx] for idx in pk_order if idx > 0]
    return pk_indices


def pairings_to_dbn(pairings_list: list, dim: int):
    """
    Converts the pairing indices list into a nucleic acid strand in dot-bracket-letter-notation.

    Args:
        pairings_list (list): List indicating pairings.
        dim (int): The number of bases in the strand.

    Returns:
        pairings_dbn (str): Pairings in dot_bracket_notation.
    """
    pairings_list = np.array(pairings_list)
    pairings_dbn = biotite.structure.dot_bracket(pairings_list, dim)[0]

    return pairings_dbn


def kth_diag_indices(matrix: np.ndarray, k: int):
    """
    SOURCE: https://stackoverflow.com/questions/10925671/numpy-k-th-diagonal-indices
    --------------------------------------------------

    Gets indices of the k-th diagonal of a 2x2 matrix.

    Args:
      matrix (np.ndarray): Matrix.
      k (int): Offset from the main diagonal (0 = main diagonal)

    Returns:
      row (np.ndarray): Row values of the indices.
      col (np.ndarray): Column values of the indeces.
    """
    if matrix.ndim != 2:
        raise ValueError("Matrix should 2D.")
    rowidx, colidx = np.diag_indices_from(matrix)

    # rowidx and colidx share the same buffer
    colidx = colidx.copy()

    if k > 0:
        colidx += k
    else:
        rowidx -= k
    k = np.abs(k)

    row = rowidx[:-k]
    col = colidx[:-k]

    return row, col


def set_diagonals_to_zero(matrix: np.ndarray):
    """
    Sets main diagonal and k=1 offset diagonal to zero.
    This ensure no interference with Edmund's matching algorithm.

    Args:
      matrix (np.ndarray): Probability matrix.

    Returns:
      matrix (np.ndarray): Probability matrix with diagonals set to 0.
    """
    offset = [-1, 0, 1]
    for k in offset:
        matrix[kth_diag_indices(matrix, k)] = 0
    return matrix


def plot_dbn_graph(pairings_list: str, sequence: str, filename: str = None):
    """
    ADAPTED FROM: Tom David Müller
    LICENSE: BSD 3 clause
    --------------------------------------------------

    Plots the RNA secondary structure as an arc graph.

    Args:
      pairings_list (list): Pairings as a list of tuples.
      sequence (str): Base names.
      filname (str): Path to file (.png).

    Returns:
      None

    Raises:
      TypeError: If pairing
    """

    if not isinstance(pairings_list, np.ndarray):
        raise TypeError("pairing should be of type np.ndarray")
    # Code source: Tom David Müller
    # License: BSD 3 clause
    length = len(sequence)
    residue_ids = [num for num in range(length)]

    # Create a matplotlib pyplot
    fig, ax = plt.subplots(figsize=(8.0, 4.5))

    # Setup the axis
    ax.set_xlim(0.5, length + 0.5)
    ax.set_ylim(0, length / 2 + 0.5)
    ax.set_aspect("equal")
    ax.xaxis.set_major_locator(matplotlib.ticker.MultipleLocator(3))
    ax.tick_params(axis="both", which="major", labelsize=8)
    ax.set_yticks([])

    # Remove the frame
    plt.box(False)

    # Plot the residue names in order
    for residue_name, residue_id in zip(sequence, residue_ids):
        ax.text(residue_id, 0, residue_name, ha="center", fontsize=8)

    # Compute the basepairs and pseudknot order (first result)
    pseudoknot_order = get_pk_order(pairings_list)

    # Draw the arcs between base pairs
    for (base1, base2), order in zip(pairings_list, pseudoknot_order):
        base1_res_id = residue_ids[base1]
        base2_res_id = residue_ids[base2]
        arc_center = (np.mean((base1_res_id, base2_res_id)), 1.5)
        arc_diameter = abs(base2_res_id - base1_res_id)
        name1 = sequence[base1]
        name2 = sequence[base2]
        if sorted([name1, name2]) in [["A", "U"], ["C", "G"]]:
            color = biotite.colors["dimorange"]
        else:
            color = biotite.colors["brightorange"]
        if order == 0:
            linestyle = "-"
        elif order == 1:
            linestyle = "--"
        else:
            linestyle = ":"
        arc = matplotlib.patches.Arc(
            arc_center,
            arc_diameter,
            arc_diameter,
            theta1=0,
            theta2=180,
            color=color,
            linewidth=1.5,
            linestyle=linestyle,
        )
        ax.add_patch(arc)

    if filename:
        plt.savefig(filename)

    # Display the plot
    plt.show()

    return None


def plot_dbn_figure(pairings_dbn: str, sequence: str):
    """
    Plots the RNA secondary structure as a 2D figure.

    Args:
      pairings_dbn (str): Pairings in dot-bracket notation.
      sequence (str): Base names.

    Returns:
      bulge_graph (forgi.graph.bulge_graph.BulgeGraph): Information of the bulge graph.
    """
    bulge_graph = forgi.graph.bulge_graph.BulgeGraph.from_dotbracket(
        pairings_dbn, sequence
    )
    forgi.visual.mplotlib.plot_rna(
        bulge_graph,
        text_kwargs={"fontweight": "black"},
        lighten=0.7,
        backbone_kwargs={"linewidth": 3},
    )

    plt.show()

    return bulge_graph


def save_dbn_figure(
    pairings_dbn: str, sequence: str, filename: str, file_type: str = "png"
):
    """
    Saves an RNA figure as png/svg.

    Args:
      pairings_dbn (str): Pairings in dot-bracket notation.
      sequence (str): Base names.
      filename (str): Name of the image file.
      file_type (str): Image file type (png, svg).

    Returns:
      None

    Raises:
      ValueError: If 'file_type' is neither 'png' or 'svg'.
    """
    file_type = file_type.upper()

    if file_type == "PNG":
        bulge_graph = forgi.graph.bulge_graph.BulgeGraph.from_dotbracket(
            pairings_dbn, sequence
        )
        forgi.visual.mplotlib.plot_rna(
            bulge_graph,
            text_kwargs={"fontweight": "black"},
            lighten=0.7,
            backbone_kwargs={"linewidth": 3},
        )
        plt.savefig(filename)
    elif file_type == "SVG":
        ViennaRNA.svg_rna_plot(sequence, pairings_dbn, filename)
    else:
        raise ValueError("'file_type' must either be 'png' or 'svg'.")

    return None
