import numpy as np
import pandas as pd
import tensorflow as tf
from utils.GetDataFromDFUtils import *


def get_data_from_bprna(
    bprna: pd.DataFrame,
    columns: list = ["none"],
    split: bool = False,
    num_samples: int = 0,
    random_state: int = -1,
    max_len: int = 0,
    min_dist: int = 3,
    create_tensor_sequence: bool = False,
    create_tensor_structure: bool = False,
):
    """
    Notes:
    - Order of returns: create_tensor_sequence, create_tensor_structure, bpRNA columns
    - get_one_hot_sequence was used for LSTM model to create Lx4 tensors, but now LxLx8 tensors are used

    Args:
        columns: List of column names to be returned (list).
        (name, length, sequence, pairings, structure, pseudoknot)

    Returns:
        sequence_tensor:
        structure_tensor:
        columns:

    Raises:
        ValueError: If 'num_samples' is greater than 28,370 (# of samples in bpRNA).

    To do:
    - create a for_test option for that will return structure_matrix
        - automatically return sequence_tensor
    - if create_tensor options are not selected, columns can not be empty
    """

    ### Raises
    if (
        "name" not in columns
        and "length" not in columns
        and "sequence" not in columns
        and "pairings" not in columns
        and "structure" not in columns
        and "pseudoknot" not in columns
        and "all" not in columns
        and "none" not in columns
    ):
        raise ValueError(
            "'columns' must be a list with the following options: name, length, sequence, pairings, structure, pseudoknot, processed_sequences, processed_structures, feature_tensors, all (for all), none (default, for none)"
        )
    if num_samples > 28370:
        raise ValueError("'num_samples' exceeds number of samples in bpRNA")

    if split and not columns:
        raise ValueError("'columns' can not be empty if 'split' is True")

    if "all" in columns and len(columns) > 1:
        raise ValueError(
            "'columns' must be specified with either 'all' or individual column names"
        )
    ###

    if max_len != 0:
        bprna = bprna[bprna["length"] <= max_len]

    if num_samples != 0 and random_state > -1:
        bprna = bprna.sample(n=num_samples, random_state=random_state)
    # If random_state is -1, get the first x samples
    elif num_samples != 0:
        bprna = bprna.head(num_samples)

    num_samples = bprna.shape[0]

    # If pad is True, max_len must be set
    max_len = bprna["length"].max() if (max_len == 0) else max_len

    returns = []

    processed_sequences = []
    processed_structures = []

    ### Sequences
    if create_tensor_sequence:
        for idx in range(num_samples):
            tensor = build_feature_tensor(bprna["sequence"].iloc[idx], min_dist)
            encoded_tensor = encode_feature_tensor(tensor)
            padded_tensor = pad_feature_tensor(encoded_tensor, max_len)
            tensor_converted_reshaped = np.transpose(
                convert_torch_tensor(padded_tensor), (1, 2, 0)
            )

            processed_sequences.append(tensor_converted_reshaped)

        sequence_tensor = create_tensor(processed_sequences)
        returns.append(sequence_tensor)

    ### Structures
    if create_tensor_structure:
        for idx in range(num_samples):
            pairing = bprna["pairings"].iloc[idx]
            length = bprna["length"].iloc[idx]
            pairings = get_pairings(pairing)
            matrix = build_matrix(pairings, length)
            matrix_expand = torch.from_numpy(matrix).expand((1, length, length))
            padded_matrix = pad_feature_tensor(matrix_expand, max_len)
            reshaped_matrix = torch.reshape(padded_matrix, (max_len, max_len, 1))

            processed_structures.append(reshaped_matrix)
        structure_tensor = create_tensor(processed_structures)
        returns.append(structure_tensor)

    if "none" not in columns:
        if split:
            for column in columns:
                returns.append(bprna[column])
        elif not split:
            returns.append(bprna[columns])

    return returns[0] if len(returns) == 1 else returns
