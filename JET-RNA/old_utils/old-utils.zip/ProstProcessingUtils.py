import numpy as np
import biotite as bio
from biotite.structure import dot_bracket, dot_bracket_from_structure, pseudoknots
import networkx as nx

import torch
from torch import cuda

device = torch.device("cuda") if cuda.is_available() else torch.device("cpu")

"""
Requires biotite package.
"""


def unpad_matrix(padded_matrix, true_len, pos_matrix="m"):
    """
    Turn a padded matrix into an unpadded one.

    Args:
        padded_matrix: Matrix to be unpadded.
        true_len: Length of the original matrix.
        pos_matrix: Where the original matrix is positioned (middle, upper left).
            m: Middle.
            ul: Upper left

    Returns:
        unpadded_matrix: The unpadded matrix.

    Raises:
        ValueError: If true_len is larger than the length of the padded matrix.
        ValueError: Dimesions of matrix must be n x n.
    """
    current_size = padded_matrix.shape[0]
    dims = np.ndims(padded_matrix)

    if true_len > current_size:
        raise ValueError(
            "Length of the final matrix is larger than the length of the padded matrix."
        )
    if dims != 2:
        raise ValueError("Dimesions of matrix must be n x n.")

    pad_len = current_size // 2 - true_len // 2

    unpadded_matrix = padded_matrix[
        pad_len : pad_len + true_len, pad_len : pad_len + true_len
    ]

    return unpadded_matrix


def threshold_probability(predicted_matrix, threshold):
    """
    Converts probability values into 0 (unpaired) or 1 (paired).
    DON'T USE. WAS TEMP USED BEFORE BLOSSOMS ALGORITHM.

    Args:
        predicted_matrix: Matrix with pairing probabilities.
        threshold: Cutoff value for pairing probability.

    Returns:
        target_matrix: Matrix with 0s and 1s to indicate pairing.
    """

    target_matrix = np.where(predicted_matrix > threshold, 0, 1)

    return target_matrix


def edmunds_matching_algorithm(target_matrix, n=0):
    # dim = target_matrix.shape[0]

    # pairings = nx.matching.max_weight_matching(G)

    A = target_matrix.clone()
    n = A.size(-1) if n == 0 else n
    mask = torch.eye(n, device=device) * 2
    big_a = torch.zeros((2 * n, 2 * n), device=device)
    big_a[:n, :n] = A
    big_a[n:, n:] = A
    big_a[:n, n:] = A * mask
    big_a[n:, :n] = A * mask
    G = nx.from_numpy_array(np.array(big_a.cpu().data))
    pairings = nx.matching.max_weight_matching(G)
    y_out = torch.zeros_like(A)
    for i, j in pairings:
        if i > n and j > n:
            continue
        y_out[i % n, j % n] = 1
        y_out[j % n, i % n] = 1
    return pairings, y_out


def get_pk_idx(pairings, max_pseudoknot_order=0):
    """
    Gets the pseudoknot values from a list of paired indices.

    **A pseudoknot is present when, given 2 base pairs (i,j), (i',j'),
    either i < i' < j < j' or i' < i < j' < j.

    In other words, a base pair doesn't end before the previous one.
    (first to enter, last to leave)
    SOURCE: bpRNA

    Args:
        pairings: List containing pairings (np.ndarray).

    Returns:
        pk_indices: List containing indices of pairings (1 for pk, 0 for non-pk).
    """

    return pseudoknots(pairings, max_pseudoknot_order=max_pseudoknot_order)


def target_to_dbn(target_matrix, max_pseudoknot_order=None):
    """
    Converts the target matrix into predicted pairings in the form of dot-bracket notation.

    Args:
        target_matrix: Matrix indicating pairings.

    Returns:
        dbn: Pairings in dot_bracket_notation.
    """
    dim = target_matrix.shape[0]

    # # Gets the upper triangular matrix and its indices
    # upper_triangle_indices = np.triu_indices_from(target_matrix, k=1)
    # upper_triangle = target_matrix[upper_triangle_indices]

    # pairings = [
    #     (upper_triangle_indices[0][idx], upper_triangle_indices[1][idx])
    #     for idx, val in enumerate(upper_triangle)
    #     if val == 1
    # ]

    pairings = edmunds_matching_algorithm(target_matrix, dim)

    dbn = dot_bracket(pairings, dim, max_pseudoknot_order=max_pseudoknot_order)[0]

    return dbn
