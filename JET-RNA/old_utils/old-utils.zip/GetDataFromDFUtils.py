import numpy as np
import tensorflow as tf
import torch
import torch.nn as nn
from torch import cuda

# CNNFold
bases = ["A", "U", "G", "C"]
device = torch.device("cuda") if cuda.is_available() else torch.device("cpu")


def create_tensor(series):
    """
    Creates a float32 tensor from a Series of 2D matrix.
    """
    arrays = []
    for i in series:
        arrays.append(i)

    tensor = np.stack(arrays)
    tensor_float32 = tensor.astype(np.float32)

    return tensor_float32


def build_feature_tensor(sequence, min_dist):
    """
    Creates a LxLx8 feature tensor for a sequence.

    Args: sequence (str), min_dist (int)

    Returns: PyTorch Tensor (which is eventually converted to Tensorflow Tensor)

    SOURCE: SPOT-RNA
    Create input matrix which is 16xNxN or 1xNxN according to the onehot value
    At the moment works faster than the previous one (matrix multiplication vs normal loop)

    We have 16 different pairing types w.r.t [A, U, G, C]
        0, 5, 10, 15 are self_loops (unpair) --> 1
        1, 4, 6, 9, 11, 14 are pairings --> 6
        others are invalid --> 1
        = 8 modes (channels)

    matrix[0] = itself
    matrix[1-6] = pairings
    matrix[7] = invalid
    """
    n = len(sequence)
    invalid = []
    seq = []
    for i, s in enumerate(sequence):
        if s not in bases:
            invalid.append(i)
            seq.append(0)
        else:
            seq.append(bases.index(s))

    seq = torch.tensor(seq, device=device)

    q2 = seq.repeat(n, 1)
    q1 = q2.transpose(1, 0)
    t = torch.stack(
        ((torch.abs(q1 - q2) == 1).long(), torch.eye(n, device=device).long())
    )
    mask = torch.max(t, 0)[0]
    flat_mat = (q1 * 4 + q2 + 1) * mask

    for i in range(1, min_dist + 1):
        flat_mat[range(n - i), range(i, n)] = 0
        flat_mat[range(i, n), range(n - i)] = 0

    flat_mat = flat_mat.unsqueeze(0)

    return flat_mat


def encode_feature_tensor(flat_mat):
    n = flat_mat.shape[1]
    mat = torch.zeros((17, n, n), device=device)
    idx2 = torch.arange(n).repeat(n, 1)
    idx1 = idx2.transpose(1, 0).reshape(-1)
    idx2 = idx2.reshape(-1)
    mat[flat_mat.reshape(-1), idx1, idx2] = 1
    mat = mat[1:]
    mat8 = mat[[1, 4, 6, 9, 11, 14]]

    mat8 = torch.cat((mat8, torch.sum(mat[[0, 5, 10, 15]], 0).unsqueeze(0)), 0)
    mat8 = torch.cat((mat8, 1 - torch.sum(mat8, 0).unsqueeze(0)), 0)
    return mat8


def build_matrix(pairings, size):
    """Builds adjacency matrix from list of pairings.
    Code by: INSERT REFERENCE

    Returns:
        _type_: _description_
    """
    mat = np.zeros((size, size))

    for i in range(size):  # neigbouring bases are linked as well
        if i < size - 1:
            mat[i, i + 1] = 1
        if i > 0:
            mat[i, i - 1] = 1

    for i, j in pairings:
        mat[i, j] = 1
        mat[j, i] = 1

    return mat


def convert_torch_tensor(torch_matrix):
    """
    Converts PyTorch Tensor to Tensorflow Tensor.
    """
    return tf.convert_to_tensor(torch_matrix.numpy())


"""Builds pairings from DBN.
Code by: INSERT REFERENCE

Returns:
    pairings: list of paired bases
"""

import numpy as np


def get_pairings(structure):
    """
    For each closing parenthesis, I find the matching opening one and store their index in the pairings list.
    The assigned list is used to keep track of the assigned opening parenthesis

    SOURCE:
    """
    opened = [
        index
        for index, bracket in enumerate(structure)
        if bracket == "(" or bracket == "["
    ]
    closed = [
        index
        for index, bracket in enumerate(structure)
        if bracket == ")" or bracket == "]"
    ]

    assert len(opened) == len(closed)

    assigned = []
    pairings = []

    for close_index in closed:
        for open_index in opened:
            if open_index < close_index:
                if open_index not in assigned:
                    candidate = open_index
            else:
                break
        assigned.append(candidate)
        pairings.append([candidate, close_index])

    assert len(pairings) == len(opened)

    return pairings


# one hot sequence
def get_one_hot_sequence(sequence):
    bases = np.array(["A", "U", "G", "C"])
    encoding = []
    for i in range(len(sequence)):
        if i == "P":
            encoding[i].append([0, 0, 0, 0])
        encoding.append([])
        for j in range(len(bases)):
            if sequence[i] == bases[j]:
                encoding[i].append(1)
            else:
                encoding[i].append(0)
    return np.array(encoding)


def pad_feature_tensor(mat, final_size, insert_mode="m", padding_value=-1):
    """
    mat has size (k, n, n)
    Create a matrix with size (k, final_size, final_size)
    put the mat in it according to insert_mode:
        m: put mat at the center
        lt: left top
        r: random
    """
    n = mat.shape[-1]
    if final_size < n:
        raise ValueError("Final size should be greater or equal than the current size!")
    final_mat = torch.ones((mat.shape[0], final_size, final_size), device=device)
    final_mat = final_mat * padding_value
    if insert_mode == "m":
        i = final_size // 2 - n // 2
        final_mat[:, i : i + n, i : i + n] = mat
    return final_mat
