from ProstProcessingUtils import (
    unpad_matrix,
    edmunds_matching_algorithm,
    get_pk_idx,
    target_to_dbn,
)


def post_processing(
    predictions,
    true_lengths,
    unpad: bool = True,
    pos_matrix: str = "m",
    return_unpadded_matrices: bool = False,
    return_edmunds_matrices: bool = False,
    return_pairings: bool = False,
    return_dbn: bool = True,
    return_pk_indices: bool = False,
    max_pseudoknot_order: int = 0,
):
    """
    Processes the predictions made by model into pairings in dot-bracket notation.

    Args:
        predictions: List of predicted target matrices (list).
        true_lengths: List of true lengths (list).
        unpad: If matrices need to be unpadded (bool).
        pos_matrix:
        return_edmunds_matrix: If target matrix is to be returned (bool).
        return_pairings:
        return_dbn: If dot-bracket notation is to be returned (bool).
        return_pk_indices:
        max_pseudoknot_order:

    Returns:
        processed_matrix: Target matrix
        dbn: Dot-bracket notation.
        pk_indices

    Raises:
    """
    returns = []
    unpadded_predictions = []
    edmunds_matrices = []
    pairings = []
    pk_indices = []
    dbn_list = []

    if unpad:
        for idx in range(len(predictions)):
            unpadded_predictions.append(
                unpad_matrix(predictions[idx], true_lengths[idx], pos_matrix=pos_matrix)
            )

        if return_edmunds_matrices or return_pairings or return_pk_indices:
            for matrix in unpadded_predictions:
                pairing, edmunds_matrix = edmunds_matching_algorithm(matrix)
                pairings.append(pairing)
                edmunds_matrices.append(edmunds_matrix)

        if return_dbn:
            for matrix in unpadded_predictions:
                dbn_list.append(target_to_dbn(matrix))

    if not unpad:
        if return_edmunds_matrices or return_pairings or return_pk_indices:
            for matrix in predictions:
                pairing, edmunds_matrix = edmunds_matching_algorithm(matrix)
                pairings.append(pairing)
                edmunds_matrices.append(edmunds_matrix)

        if return_dbn:
            for matrix in unpadded_predictions:
                dbn_list.append(target_to_dbn(matrix))

    # Returns
    if return_unpadded_matrices:
        returns.append(unpadded_predictions)
    if return_edmunds_matrices:
        returns.append(edmunds_matrices)
    if return_pairings:
        returns.append(pairings)
    if (
        return_pk_indices
    ):  # pk_indices processing done outside of "if unpad/not unpad because pairings will be produced regardless"
        for pairing in pairings:
            pk_indices.append(get_pk_idx(pairing))
        returns.append(pk_indices)
    if return_dbn:
        returns.append(dbn_list)
